// Developed by Erick Pombo Sonderblohm
// http://sonderblohm.net/
// https://www.linkedin.com/in/erick-pombo-sonderblohm-49883a58/

The output in this file renders a green plastic material, the light color is changin over time to get interesting effects on the material over time.